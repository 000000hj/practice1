document.querySelector('#p-detail').style.visibility='hidden';
document.querySelector('#h3-detail').style.visibility='hidden';
